#!/bin/sh

#THE BORING PART:

#THIS SOFTWARE FILE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS “AS IS” AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#No liability for the contents of this document can be accepted. Use the concepts, examples and information at your own risk. There may be errors, omissions, and inaccuracies that could cause you to lose data, harm your system, or induce involuntary electrocution, so proceed with appropriate caution. The author takes no responsibility for any damages, incidental or otherwise.
#"ChatGPT ELI5 please" "Sure, If you use this software, it's like using a toy we're sharing with you. We think it's a cool toy, but we're not promising it'll always work perfectly. If something goes wrong while you're playing with it—like it breaks or doesn't do what you thought it would—we're sorry, but you can't blame us. Play and use at your own risk!, Remember, while this CHatGPT explanation is ELI5-friendly It's a way to convey the idea, but not a substitute of the official one above"

#THE FUN PART:

#this script works on a vultr.com LEMP Provisioned server
#STEPS YOU NEED TO FOLLOW:
#1) Vultr.com: Deploy a new LEMP server at Vultr.com, write down the IP address.
#2) Your Domain Name Registar: Go to your domain registar and point A records to that IP Address. Also Set the CNAME for www
#3) SSH into your deplyed server
#4) copy this script into /usr/share/nginx
#5) See below and make sure any line that says "THIS THIS" has the correct information
#6) go to /usr/share/nginx and # bash us_install.sh
#7) WAIT until you see "END OF BATCH SCRIPT"

#THIS THIS: make sure this is the URL path to the latest version of USERSPICE
sourceurl=https://github.com/mudmin/releases/raw/master/UserSpice56.zip  


#THIS THIS: you MUST adjust these variables to your own configuration
domainname=xyz.com


#THIS THIS: GMAILAddressUsername (for letsencryptregistration)
adminemailaddress=xyz@gmail.com

#>>>>>TEST THIS CODE

#>>>>>END OF TEST so
#exit


#Get a the letsencrypt certificate installed AFTER we check if the domain name is allready pointing to this server's IP address

#get this servers public IP address
extaddr=$(curl -s ifconfig.me)
echo "The external IP address is ---$extaddr--- (from cURL)"

#get the domains servers public IP address
domainip=$(dig $domainname +short)
echo "The domain $domainname IP address is ---$domainip--- (from dig)"

if [ $domainip != $extaddr ]; then
  echo "IPs are not equal, we can't letsencrypt"
  exit #end batch script
else
  echo "IPs are equal, it is ok to letsencrypt"
fi

#Before running Certbot, make sure server_name is set properly. Edit your Nginx configuration

echo '' > /etc/nginx/sites-available/http.conf 
{ 
echo '
server {
	listen 80 default_server;
	listen [::]:80 default_server;
	server_name '$domainname';

	root /usr/share/nginx/'$domainname';
	index index.php index.html;

	# set max upload size
	client_max_body_size 2G;
	fastcgi_buffers 64 4K;

	server_tokens off;

	include /etc/nginx/site-extras/*.conf;

	access_log /var/log/nginx/http_access.log combined;
	error_log /var/log/nginx/http_error.log;

	location = /favicon.ico {
		log_not_found off;
		access_log off;
	}

	location = /robots.txt {
		allow all;
		log_not_found off;
		access_log off;
	}

	location ~ \.php$
	{
		try_files      $uri =404;
		fastcgi_pass   127.0.0.1:9000;
		fastcgi_index  index.php;
		fastcgi_param  SCRIPT_FILENAME  $document_root$fastcgi_script_name;
		include        fastcgi_params;
	}

	location ~* \.(htaccess|htpasswd) {
		deny all;
	}

	# set long EXPIRES header on static assets
	location ~* \.(?:jpg|jpeg|gif|bmp|ico|png|css|js|swf)$ {
		expires 30d;
		access_log off;
	}

}
' 
} >> /etc/nginx/sites-available/http.conf 

echo '' > /etc/nginx/sites-available/https.conf 
{ 
echo '
server {
	listen 443 ssl default_server;
	listen [::]:443 ssl default_server;
	server_name '$domainname';

	ssl_certificate /etc/nginx/ssl/server.crt;
	ssl_certificate_key /etc/nginx/ssl/server.key;

	root /usr/share/nginx/'$domainname';
	index index.php index.html;

	# set max upload size
	client_max_body_size 2G;
	fastcgi_buffers 64 4K;

	server_tokens off;

	include /etc/nginx/site-extras/*.conf;

	access_log /var/log/nginx/https_access.log combined;
	error_log /var/log/nginx/https_error.log;

	location = /favicon.ico {
		log_not_found off;
		access_log off;
	}

	location = /robots.txt {
		allow all;
		log_not_found off;
		access_log off;
	}

	location ~ \.php$
	{
		try_files      $uri =404;
		fastcgi_pass   127.0.0.1:9000;
		fastcgi_index  index.php;
		fastcgi_param  SCRIPT_FILENAME  $document_root$fastcgi_script_name;
		include        fastcgi_params;
	}

	location ~* \.(htaccess|htpasswd) {
		deny all;
	}

	# set long EXPIRES header on static assets
	location ~* \.(?:jpg|jpeg|gif|bmp|ico|png|css|js|swf)$ {
		expires 30d;
		access_log off;
	}

}

' 
} >> /etc/nginx/sites-available/https.conf 

#restart nginx to process changes
systemctl restart nginx


#Verify snapd is up to date.
snap install core; sudo snap refresh core
#Remove certbot-auto and any Certbot OS packages.
apt-get remove certbot
#Install Certbot with Snap.
snap install --classic certbot
#Link Certbot to /usr/bin.
ln -s /snap/bin/certbot /usr/bin/certbot
#Run Certbot for Nginx.
certbot --nginx --redirect -d $domainname -d www.$domainname -m $adminemailaddress --agree-tos
#Verify the timer is active.
systemctl list-timers | grep 'certbot\|ACTIVATES'
#Verify the crontab entry exists.
ls -l /etc/cron.d/certbot
#PATIENCE MESSAGE
echo "PATIENCE, THIS NEXT TEST WILL TAKE 60 seconds"
#Verify the renewal process works with a dry run.
certbot renew --dry-run

#


#LET'S MAKE A DIRECTORY FOR ALL THE PHP
mkdir -p $domainname
sudo chmod ugo+w $domainname 

#DOWNLOAD USERSPICE AND UNZIP
curl -L "$sourceurl" -o "file.zip"
unzip file.zip -d $domainname
rm file.zip

#adjust permissions
chmod 666 /usr/share/nginx/$domainname/users/init.php
find /usr/share/nginx/$domainname -type f -exec chmod 666 {} \;


echo "END OF BATCH SCRIPT, now go to $domainname with your browser to complete the instalation"